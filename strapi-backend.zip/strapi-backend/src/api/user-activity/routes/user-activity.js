'use strict';

/**
 * user-activity router
 */

const { createCoreRouter } = require('@strapi/strapi').factories;

module.exports = createCoreRouter('api::user-activity.user-activity');
